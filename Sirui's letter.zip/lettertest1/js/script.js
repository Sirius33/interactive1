
    $('A').click(function(){
     toggle();  
      });
    
