
    $('document').ready(function(){
      $(window).keypress(function(){
        $('body').toggleClass('colorful');  
      });
    });
 